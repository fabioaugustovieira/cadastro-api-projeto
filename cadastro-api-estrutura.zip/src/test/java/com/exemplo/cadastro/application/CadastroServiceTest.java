package com.exemplo.cadastro.application;

import com.exemplo.cadastro.domain.Cadastro;
import com.exemplo.cadastro.infrastructure.repository.CadastroRepository;
import org.junit.jupiter.api.Test;

import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CadastroServiceTest {
    @Test
    void deveBuscarCadastroPorId() {
        CadastroRepository repo = mock(CadastroRepository.class);
        Cadastro cadastro = new Cadastro("Ana", "Silva", 25, "Brasil");
        when(repo.findById(cadastro.getId())).thenReturn(Optional.of(cadastro));

        CadastroServiceImpl service = new CadastroServiceImpl(repo);
        Cadastro resultado = service.buscarPorId(cadastro.getId());

        assertEquals("Ana", resultado.getNome());
    }
}
