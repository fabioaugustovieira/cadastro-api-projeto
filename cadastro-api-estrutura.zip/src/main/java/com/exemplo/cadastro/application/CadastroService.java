package com.exemplo.cadastro.application;

import com.exemplo.cadastro.domain.Cadastro;
import java.util.List;
import java.util.UUID;

public interface CadastroService {
    UUID criarCadastro(Cadastro cadastro);
    Cadastro buscarPorId(UUID id);
    List<Cadastro> listarTodos();
    void atualizar(UUID id, String campo, String valor);
    void deletar(UUID id);
    void processarNotificacoes();
}
