package com.exemplo.cadastro.infrastructure.email.impl;

import com.exemplo.cadastro.domain.Cadastro;
import com.exemplo.cadastro.infrastructure.email.NotificacaoService;
import org.springframework.stereotype.Service;

@Service
public class SesNotificacaoService implements NotificacaoService {
    @Override
    public void notificarCadastroPendente(Cadastro cadastro) {
        System.out.println("Notificando por email: " + cadastro.getNome());
    }
}
