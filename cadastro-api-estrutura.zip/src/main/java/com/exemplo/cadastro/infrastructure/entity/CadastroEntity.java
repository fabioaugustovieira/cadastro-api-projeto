package com.exemplo.cadastro.infrastructure.entity;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
public class CadastroEntity {
    @Id
    private UUID id;
    private String nome;
    private String sobrenome;
    private int idade;
    private String pais;
    private boolean aprovado;
    private boolean notificado;
    private Instant createdAt;

    // Getters, Setters e Construtores
}
