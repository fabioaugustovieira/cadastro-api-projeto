package com.exemplo.cadastro.infrastructure.scheduler;

import com.exemplo.cadastro.infrastructure.repository.CadastroRepository;
import com.exemplo.cadastro.infrastructure.email.NotificacaoService;
import com.exemplo.cadastro.infrastructure.entity.CadastroEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.Duration;
import java.util.List;

@Component
@RequiredArgsConstructor
public class NotificacaoScheduler {
    private final CadastroRepository repository;
    private final NotificacaoService notificacaoService;

    @Scheduled(fixedRate = 60000)
    public void processarNotificacoes() {
        Instant agora = Instant.now();
        List<CadastroEntity> pendentes = repository.findByAprovadoFalseAndNotificadoFalse();

        for (CadastroEntity cadastro : pendentes) {
            if (cadastro.getCreatedAt().isBefore(agora.minus(Duration.ofMinutes(2)))) {
                notificacaoService.notificarCadastroPendente(cadastro.toDomain());
                cadastro.setNotificado(true);
                repository.save(cadastro);
            }
        }
    }
}
