package com.exemplo.cadastro.infrastructure.email;

import com.exemplo.cadastro.domain.Cadastro;

public interface NotificacaoService {
    void notificarCadastroPendente(Cadastro cadastro);
}
