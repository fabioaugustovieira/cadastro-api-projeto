package com.exemplo.cadastro.domain;

import java.time.Instant;
import java.util.UUID;

public class Cadastro {
    private UUID id;
    private String nome;
    private String sobrenome;
    private int idade;
    private String pais;
    private boolean aprovado;
    private boolean notificado;
    private Instant createdAt;

    public Cadastro(String nome, String sobrenome, int idade, String pais) {
        this.id = UUID.randomUUID();
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.idade = idade;
        this.pais = pais;
        this.aprovado = false;
        this.notificado = false;
        this.createdAt = Instant.now();
    }

    // Getters e Setters
}
