package com.exemplo.cadastro.api;

import com.exemplo.cadastro.application.CadastroService;
import com.exemplo.cadastro.domain.Cadastro;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/cadastros")
@RequiredArgsConstructor
public class CadastroController {

    private final CadastroService service;

    @PostMapping
    public ResponseEntity<Void> criar(@RequestBody CadastroDTO dto) {
        service.criarCadastro(dto.toDomain());
        return ResponseEntity.accepted().build();
    }

    @GetMapping("/{id}")
    public CadastroDTO buscar(@PathVariable UUID id) {
        return CadastroDTO.fromDomain(service.buscarPorId(id));
    }

    @GetMapping
    public List<CadastroDTO> listar() {
        return service.listarTodos().stream().map(CadastroDTO::fromDomain).toList();
    }

    @PatchMapping("/{id}")
    public void atualizar(@PathVariable UUID id, @RequestBody AtualizacaoDTO dto) {
        service.atualizar(id, dto.getCampo(), dto.getValor());
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable UUID id) {
        service.deletar(id);
    }
}
