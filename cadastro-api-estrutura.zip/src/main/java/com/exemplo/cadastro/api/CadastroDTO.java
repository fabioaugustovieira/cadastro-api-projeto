package com.exemplo.cadastro.api;

import com.exemplo.cadastro.domain.Cadastro;

public class CadastroDTO {
    private String nome;
    private String sobrenome;
    private int idade;
    private String pais;

    public Cadastro toDomain() {
        return new Cadastro(nome, sobrenome, idade, pais);
    }

    public static CadastroDTO fromDomain(Cadastro cadastro) {
        CadastroDTO dto = new CadastroDTO();
        dto.nome = cadastro.getNome();
        dto.sobrenome = cadastro.getSobrenome();
        dto.idade = cadastro.getIdade();
        dto.pais = cadastro.getPais();
        return dto;
    }
}
