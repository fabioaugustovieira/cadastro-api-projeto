# Cadastro API

API REST com arquitetura hexagonal para gerenciamento de cadastros e notificação por e-mail com atraso de 2 minutos.

## Funcionalidades
- Criar, listar, buscar, atualizar e deletar cadastros
- Notificação por email via SES com atraso
- Observabilidade com Prometheus, Grafana, Jaeger

## Requisitos
- Docker + Compose
- AWS CLI configurado
- Terraform instalado

## Implantação
```bash
git clone https://github.com/seu-usuario/cadastro-api.git
cd cadastro-api
terraform init && terraform apply
docker-compose up --build
```

## Observabilidade
- Prometheus + Grafana
- Jaeger para tracing
- Logs via CloudWatch (ou ELK)

## TLS
- Certificados via ACM no API Gateway
